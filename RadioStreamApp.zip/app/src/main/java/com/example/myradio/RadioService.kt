package com.example.myradio

import android.app.*
import android.content.Intent
import android.media.MediaPlayer
import android.os.IBinder
import androidx.core.app.NotificationCompat

class RadioService : Service() {
    private var player: MediaPlayer? = null
    private val CHANNEL_ID = "RadioChannel"

    override fun onCreate() {
        super.onCreate()

        player = MediaPlayer().apply {
            setDataSource("http://24.254.73.112:8000/stream")
            setOnPreparedListener { it.start() }
            prepareAsync()
        }

        createNotificationChannel()
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("My Radio")
            .setContentText("Streaming Live")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()

        startForeground(1, notification)
    }

    override fun onDestroy() {
        player?.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val serviceChannel = NotificationChannel(
            CHANNEL_ID,
            "Radio Playback",
            NotificationManager.IMPORTANCE_LOW
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(serviceChannel)
    }
}
